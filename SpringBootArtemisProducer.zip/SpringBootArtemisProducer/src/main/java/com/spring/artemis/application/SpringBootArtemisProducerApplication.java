package com.spring.artemis.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.core.JmsTemplate;

@SpringBootApplication
public class SpringBootArtemisProducerApplication {

	public static int NUMBER_OF_MESSAGES_TO_PRODUCE = 20;
	
	public static void main(String[] args) {
		
		//SpringApplication.run(SpringBootArtemisProducerApplication.class, args);
		//JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);
		
		ConfigurableApplicationContext context = SpringApplication.run(ProducerConfiguration.class, args);
        JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);


		// produce 	
        for (int i = 0; i < NUMBER_OF_MESSAGES_TO_PRODUCE; i++) {
        	System.out.println("I am kind the message"+i);
        	ArtemisProducer producer = new ArtemisProducer();
        	producer.setJmsTemplate(jmsTemplate);
        	producer.sendMessage("hello dude "+i);
			
		}
        
	}

}
