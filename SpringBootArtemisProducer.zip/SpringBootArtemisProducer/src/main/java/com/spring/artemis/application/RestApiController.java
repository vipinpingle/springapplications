package com.spring.artemis.application;

import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestApiController {
	
	@Autowired
	ArtemisProducer producer;
	
	@RequestMapping("/")
    public String home() {

        return "I am here ";
    }
	
	@RequestMapping(value="/produce")
	public String produce(@RequestParam("msg")String msg) throws JMSException{
		System.out.println("I am in REstAPIController");
		producer.sendMessage(msg);
		return "Done";
	}
}