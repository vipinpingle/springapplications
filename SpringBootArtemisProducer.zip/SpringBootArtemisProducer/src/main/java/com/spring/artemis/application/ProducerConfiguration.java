package com.spring.artemis.application;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
public class ProducerConfiguration {

	/* destination */
    public static String destination = "destination";

}
