package com.spring.artemis.application;


import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component
public class ArtemisProducer {
	@Autowired
	JmsTemplate jmsTemplate;
	
	@Value("${jms.queue.destination}")
	String destinationQueue;
	
//	public void send(String msg) throws JMSException{
//		System.out.println("Artemis producer starting to send message" + destinationQueue);
//		System.out.println("Artemis producer requested message" + msg);
//		//jmsTemplate.convertAndSend(destinationQueue, msg);
//		jmsTemplate.convertAndSend("demoQueue", msg);
//	}
//	
	public void sendMessage(String message){

        MessageCreator messageCreator = createMessage(message);
        System.out.println("Created message");
        jmsTemplate.send(ProducerConfiguration.destination, messageCreator);			
	}
	
	
	private MessageCreator createMessage(final String message) {
		// Send a message
        MessageCreator messageCreator = new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {
                return session.createTextMessage(message);
            }
        };
		return messageCreator;
	}


	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

}


