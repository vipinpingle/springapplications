package com.spring.artemis.application;


import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class ArtemisProducer {
	@Autowired
	JmsTemplate jmsTemplate;
	
	@Value("${jms.queue.destination}")
	String destinationQueue;
	
	public void send(String msg) throws JMSException{
		System.out.println("Artemis producer starting to send message" + destinationQueue);
		System.out.println("Artemis producer requested message" + msg);
		//jmsTemplate.convertAndSend(destinationQueue, msg);
		jmsTemplate.convertAndSend("demoQueue", msg);
	}
}